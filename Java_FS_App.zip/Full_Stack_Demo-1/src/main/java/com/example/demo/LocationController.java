package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/locations")
public class LocationController {

    private final LocationRepository locationRepository;

    @Autowired
    public LocationController(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    @GetMapping
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    @GetMapping("/{id}")
    public Location getLocationById(@PathVariable Long id) {
        return locationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid location ID: " + id));
    }

    @PostMapping
    public Location createLocation(@RequestBody Location location) {
        return locationRepository.save(location);
    }

    @PutMapping("/{id}")
    public Location updateLocation(@PathVariable Long id, @RequestBody Location updatedLocation) {
        return locationRepository.findById(id)
                .map(location -> {
                    location.setLatitude(updatedLocation.getLatitude());
                    location.setLongitude(updatedLocation.getLongitude());
                    return locationRepository.save(location);
                })
                .orElseThrow(() -> new IllegalArgumentException("Invalid location ID: " + id));
    }

    @DeleteMapping("/{id}")
    public void deleteLocation(@PathVariable Long id) {
        locationRepository.deleteById(id);
    }

    @PostMapping("/geocode")
    public Location geocodeAddress(@RequestBody String address) {
        // Add code here to call the geocoding API and retrieve location details based on the address
        // You can use libraries like RestTemplate or WebClient to make HTTP requests

        // For demonstration purposes, let's assume the geocoding API returns the latitude and longitude
        double latitude = 37.7749;
        double longitude = -122.4194;

        return new Location(latitude, longitude);
    }
}
