import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import EmployeeService from "../EmployeeService";

const CreateEmployeeComponent = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [employee, setEmployee] = useState({
    name: "",
    dept: "",
    salary: "",
  });

  useEffect(() => {
    if (id !== "_add") {
      EmployeeService.getEmployeeById(id)
        .then((res) => {
          const { name, dept, salary } = res.data;
          setEmployee({ name, dept, salary });
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [id]);

  const saveOrUpdateEmployee = (e) => {
    e.preventDefault();
    if (id === "_add") {
      EmployeeService.createEmployee(employee)
        .then(() => {
          navigate("/employees");
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      EmployeeService.updateEmployee(employee, id)
        .then(() => {
          navigate("/employees");
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      [name]: value,
    }));
  };

  const handleCancel = () => {
    navigate("/employees");
  };

  const getTitle = () => {
    if (id === "_add") {
      return <h3 className="text-center">Add Employee</h3>;
    } else {
      return <h3 className="text-center">Update Employee</h3>;
    }
  };

  return (
    <div>
      <br />
      <div className="container">
        <div className="row">
          <div className="card col-md-6 offset-md-3">
            {getTitle()}
            <div className="card-body">
              <form>
                <div className="form-group">
                  <label>Name:</label>
                  <input
                    placeholder="Name"
                    name="name"
                    className="form-control"
                    value={employee.name}
                    onChange={handleChange}
                  />
                </div>
                <div className="form-group">
                  <label>Dept:</label>
                  <input
                    placeholder="Dept"
                    name="dept"
                    className="form-control"
                    value={employee.dept}
                    onChange={handleChange}
                  />
                </div>
                <div className="form-group">
                  <label>Salary:</label>
                  <input
                    placeholder="Salary"
                    name="salary"
                    className="form-control"
                    value={employee.salary}
                    onChange={handleChange}
                  />
                </div>

                <button
                  className="btn btn-success"
                  onClick={saveOrUpdateEmployee}
                >
                  Save
                </button>
                <button
                  className="btn btn-danger"
                  onClick={handleCancel}
                  style={{ marginLeft: "10px" }}
                >
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateEmployeeComponent;
