package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullStackDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullStackDemoApplication.class, args);
	}

}
