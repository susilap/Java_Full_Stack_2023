import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import EmployeeService from "../EmployeeService";

const UpdateEmployeeComponent = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [employee, setEmployee] = useState({
    name: "",
    dept: "",
    salary: ""
  });

  useEffect(() => {
    EmployeeService.getEmployeeById(id).then((res) => {
      setEmployee(res.data);
    });
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    EmployeeService.updateEmployee(id, employee).then(() => {
      navigate("/employees");
    });
  };

  return (
    <div>
      <h2 className="text-center">Update Employee</h2>
      <form>
        <div className="form-group">
          <label>Name:</label>
          <input
            type="text"
            className="form-control"
            name="name"
            value={employee.name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Department:</label>
          <input
            type="text"
            className="form-control"
            name="dept"
            value={employee.dept}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Salary:</label>
          <input
            type="text"
            className="form-control"
            name="salary"
            value={employee.salary}
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary" onClick={handleSubmit}>
          Update
        </button>
      </form>
    </div>
  );
};

export default UpdateEmployeeComponent;
